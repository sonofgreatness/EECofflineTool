package com.example.eecofflinetool;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PdfView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf_view);
    }
}